# This is my better script
# Done using different approaches
# This script is not going to work
# This script is not good
